package editorMinimo;

// @author Radames
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.ScrollPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JToolBar;
import javax.swing.WindowConstants;
import javax.swing.filechooser.FileNameExtensionFilter;

public class GUI extends JFrame {

    private Container cp;
    private List<String> statusAnterior = new ArrayList<>();//para abrir no que estava anteriormente
    private String caminho = "";
    private JPanel painelTa = new JPanel();
    private ScrollPane scroll = new ScrollPane();
    private JTextArea textArea = new JTextArea();
    private JFileChooser caixaDeDialogo = new JFileChooser();
    private JToolBar toolBar = new JToolBar();
    ManipulaArquivo arqStatus = new ManipulaArquivo();

    public GUI() {

        setTitle("Editor de textos");

        statusAnterior = arqStatus.abrirArquivo("statusanterior.txt");
        caminho = statusAnterior.get(0);
        if (!caminho.equals("")) {
            List<String> texto;
            ManipulaArquivo arq = new ManipulaArquivo();
            texto = arq.abrirArquivo(caminho);
            textArea.setText("");
            for (int i = 0; i < texto.size(); i++) {
                textArea.append(texto.get(i) + System.getProperty("line.separator"));
            }
            setTitle("Editor - " + caminho);
        }

        setSize(600, 500);//tamanho da janela
        setLocation(new CentroDoMonitorMaior().getCentroMonitorMaior(this));
        setBackground(Color.CYAN);//cor do fundo da janela
        cp = getContentPane();//container principal, para adicionar nele os outros componentes
        cp.setLayout(new BorderLayout());//informa qual gerenciador de layout será usado

        ImageIcon iconeNovo = new ImageIcon(getClass().getResource("/icones/new_doc.png"));
        ImageIcon iconeSalvar = new ImageIcon(getClass().getResource("/icones/save.png"));
        ImageIcon iconeAbrir = new ImageIcon(getClass().getResource("/icones/folder_open.png"));

        JButton btnNovo = new JButton(iconeNovo);
        JButton btnAbrir = new JButton(iconeAbrir);
        JButton btnSalvar = new JButton(iconeSalvar);

        toolBar.add(btnNovo);
        toolBar.add(btnAbrir);
        toolBar.add(btnSalvar);

        //textarea  
        painelTa.setLayout(new GridLayout(1, 1));
        scroll.add(textArea);
        painelTa.add(scroll);

        cp.add(toolBar, BorderLayout.NORTH);
        cp.add(painelTa, BorderLayout.CENTER);

        //listeners
        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);

        //listenner ao fechar a janela
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                statusAnterior.clear();
                if (!caminho.equals("")) {
                    String aux;
                    if (caminho.substring(caminho.length() - 3, caminho.length()).equals("txt")) {
                        aux = "";
                    } else {
                        aux = ".txt";
                    }
                    statusAnterior.add(caminho + aux);
                    arqStatus.salvarArquivo("statusanterior.txt", statusAnterior);
                }
                // Sai do sistema  
                System.exit(0);
            }
        });

        btnNovo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                textArea.setText("");
                setTitle("Editor de textos");
            }
        });

        btnAbrir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                FileNameExtensionFilter filter = new FileNameExtensionFilter("TEXT FILES", "txt", "text");
                
                caixaDeDialogo.setFileFilter(filter);
                caixaDeDialogo.setFileSelectionMode(JFileChooser.FILES_ONLY);
                if (caixaDeDialogo.showOpenDialog(painelTa) == JFileChooser.APPROVE_OPTION) {
                    caminho = caixaDeDialogo.getSelectedFile().getAbsolutePath();
                    ManipulaArquivo arq = new ManipulaArquivo();
                    List<String> texto;
                    texto = arq.abrirArquivo(caminho);
                    textArea.setText("");
                    for (int i = 0; i < texto.size(); i++) {
                        textArea.append(texto.get(i) + System.getProperty("line.separator"));
                    }
                    setTitle("Editor - " + caminho);
                }
            }
        });

        btnSalvar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                FileNameExtensionFilter filter = new FileNameExtensionFilter("TEXT FILES", "txt", "text");
                caixaDeDialogo.setFileFilter(filter);
                caixaDeDialogo.setFileSelectionMode(JFileChooser.FILES_ONLY);
                if (caixaDeDialogo.showSaveDialog(painelTa) == JFileChooser.APPROVE_OPTION) {
                    caminho = caixaDeDialogo.getSelectedFile().getAbsolutePath();
                    ManipulaArquivo arq = new ManipulaArquivo();
                    List<String> textoList = new ArrayList<>();
                    String[] s = textArea.getText().split("\n" + System.getProperty("line.separator"));
                    for (int i = 0; i < s.length; i++) {
                        textoList.add(s[i] + System.getProperty("line.separator"));
                    }
                    String aux;
                    if (caminho.substring(caminho.length() - 3, caminho.length()).equals("txt")) {
                        aux = "";
                    } else {
                        aux = ".txt";
                    }
                    arq.salvarArquivo(caminho + aux, textoList);
                    setTitle("Editor - " + caminho);
                }
            }
        });
        setVisible(true);//faz a janela ficar visível

    }

}
